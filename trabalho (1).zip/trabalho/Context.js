import {useState, createContext} from 'react';

export const DataContext = createContext();

const Context = ({children}) => {
  let [nomeServico, setNomeServico] = useState(null);
  let [valorServico, setValorServico] = useState(0); 
  let [imagemServico, setImagemServico] = useState(null);
  let [servicos, setServicos] = useState([]);
  let [total, setTotal] = useState(0); 

  return (
    <DataContext.Provider 
      value={{nomeServico, setNomeServico, valorServico, setValorServico, imagemServico, setImagemServico, servicos, setServicos, total, setTotal}}>
      {children} 
    </DataContext.Provider>
  );

}

export default Context;

