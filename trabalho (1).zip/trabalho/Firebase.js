import firebase from 'firebase';

const firebaseConfig = {
  apiKey: "AIzaSyCEmPtiYpRBwPUFM9RNd6gqNkGTUM6xXHc",
  authDomain: "apptrabalho-22a0e.firebaseapp.com",
  databaseURL: "https://apptrabalho-22a0e-default-rtdb.firebaseio.com",
  projectId: "apptrabalho-22a0e"
};

if (!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
}

export default firebase;