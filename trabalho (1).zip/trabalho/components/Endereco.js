import { List, TextInput, Button, Card } from 'react-native-paper';
import {
  ScrollView,
  FlatList,
  Alert
} from 'react-native';
import {styles} from './Utils';
import { useEffect, useState } from 'react';
import firebase from '../Firebase';

export default function Enderecos () {

  let [key, setKey] = useState('');
  let [numero, setNumero] = useState('');
  let [cep, setCep] = useState('');
  let [enderecos, setEnderecos] = useState([]);
  let [cidade, setCidade] = useState([]);
  let [bairro, setBairro] = useState([]);
  let [estado, setEstado] = useState([]);
  let [tipo, setTipo] = useState([]);
  let [botaoAlterarExcluir, setBotaoAlterarExcluir] = useState(true);
  let [botaoInserir, setBotaoInserir] = useState(false);

  useEffect (() => {
    setEnderecos([]);
    selecionarTodos();
  }, []);

  const selecionarTodos = () => {
    let itens = [];
    firebase.database().ref('enderecos').orderByChild("cep").on('value', (snapshot) => {
      snapshot.forEach((linha) => {
        itens.push({
          key: linha.key,
          cep: linha.val().cep,
          bairro: linha.val().bairro,
          numero: linha.val().numero,
          cidade: linha.val().cidade,
          estado: linha.val().estado,
          tipo: linha.val().tipo
    
        });
      }); 
      enderecos(itens);
    }); 
  }

  const selecionar = (key, tipo, numero, cidade, estado, cep, bairro) =>{
    setKey(key);
    setCep(cep);
    setCidade(cidade);
    setBairro(bairro);
    setEstado(estado);
    setNumero(numero);
    setTipo(tipo);
    setBotaoAlterarExcluir(false);
    setBotaoInserir(true);
  }

  const cancelar = () => {
    setKey("");
    setNumero("");
    setBairro("");
    setEnderecos([]);
    setCidade("");
    setEstado("");
    setTipo("");
    setCep("");
    selecionarTodos();
    setBotaoAlterarExcluir(true);
    setBotaoInserir(false);
  }

  const inserirenderecos = () => {
    try {
      firebase.database().ref('enderecos').push({cep: cep, bairro: bairro, estado: estado, numero: numero, cidade: cidade, tipo: tipo});
      alert("Registro inserido com sucesso!");
      cancelar();
    } catch (e){
      alert("Erro ao inserir!");
    }
  }

  const alterarenderecos = () => {
    try {
      firebase.database().ref('enderecos').child(key).update({cep: cep, bairro: bairro, estado: estado, numero: numero, cidade: cidade, tipo: tipo});
      alert("Registro alterado com sucesso!");
      cancelar();
    } catch (e){
      alert("Erro ao alterar!");
    }
  }

  const excluirenderecos = () => {
    Alert.alert(
      "Mensagem",
      "Deseja realmente excluir esse registro?",
      [
        {
          text: "Sim",
          onPress: () => {
              try {
                firebase.database().ref('enderecos').child(key).remove();
                alert("Registro excluído com sucesso!");
                cancelar();
              } catch (e){
                alert("Erro ao excluir!");
              }
          },
        },
        {
          text: "Não",
          onPress: () => cancelar(),
        },
      ]
    );
  }

  return (
    <ScrollView>
      <Card style={{margin: 10}}>
        <Card.Title
          title="Informe o Endereço"
          subtitle="Dados do Endereço"
        />
        <Card.Content>

        
            <TextInput
            onChangeText={setTipo}
            value={tipo}
            mode="outlined"
            label="Tipo"
            placeholder="Digite o Tipo do Endereço"
          />

         <TextInput
            onChangeText={setCep}
            value={cep}
            mode="outlined"
            label="CEP"
            placeholder="Digite o CEP do Endereço"
          />
          <TextInput
            onChangeText={setEnderecos}
            value={enderecos}
            mode="outlined"
            label="RUA"
            placeholder="Digite a Rua ou Avenida do Endereço"
          />
          <TextInput
            onChangeText={setNumero}
            value={numero}
            mode="outlined"
            label="NÚMERO"
            placeholder="Digite o Número do Endereço"
          />
           
             <TextInput
            onChangeText={setBairro}
            value={bairro}
            mode="outlined"
            label="BAIRRO"
            placeholder="Digite o Bairro do Endereço"
          />

            <TextInput
            onChangeText={setCidade}
            value={cidade}
            mode="outlined"
            label="CIDADE"
            placeholder="Digite a Cidade do Endereço"
          />
     <TextInput
            onChangeText={setEstado}
            value={estado}
            mode="outlined"
            label="ESTADO"
            placeholder="Digite a Estado do Endereço"
          />
        </Card.Content>
        <Card.Actions>
          <Button icon="plus" mode="contained" style={styles.buttonCrud} disabled={botaoInserir}
            onPress={() => inserirenderecos()}>
          </Button>
          <Button icon="pencil" mode="contained"  style={styles.buttonCrud} disabled={botaoAlterarExcluir} 
            onPress={() => alterarenderecos()}>
          </Button>
          <Button icon="delete" mode="contained"  style={styles.buttonCrud} disabled={botaoAlterarExcluir}
            onPress={() => excluirenderecos()}>
          </Button>
          <Button icon="cancel" mode="contained"  style={styles.buttonCrud} 
            onPress={() => cancelar()}>
          </Button>
        </Card.Actions>
      </Card>
      <List.Section>
    <List.Subheader> Endereço registrado </List.Subheader>
      <FlatList
        data={enderecos}
        renderItem={({ item }) => {
          return (
              <List.Item
                title={item.cep}
                left={props => <List.Icon icon="arrow-right" />}
                onPress={() =>
                  selecionar(item.key, item.cep, item.tipo, item.numero, item.cidade, item.estado,item.bairro)
                }
              />
          );
        }}
      />
      </List.Section>
    </ScrollView>
    
  );
}