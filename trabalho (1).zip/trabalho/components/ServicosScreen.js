import { ScrollView, Image} from 'react-native';
import { Card, Button, Title } from 'react-native-paper';
import { styles }  from './Utils';
import { useContext } from 'react';
import { DataContext } from '../Context';

function HomeScreen({ navigation }) {
  const { setNomeServico, setValorServico, setImagemServico } =
    useContext(DataContext);

 const agendar = (nomeServico, valorServico, imagemServico) => {
setNomeServico(nomeServico);
setValorServico(valorServico);
setImagemServico(imagemServico);
navigation.navigate('Agendamento');
};

  return (
    <ScrollView style={styles.scrolview}>

      <Card style={styles.card}>
        <Card.Title title="Frango com acompanhamento" subtitle="Acompanha: salada, batata e molho. "/>
        <Card.Content>
          <Image source={require('../assets/frango com salada.jpg')} style={styles.image} />
          <Title style={styles.title}>R$35,00</Title>
        </Card.Content>
        <Card.Actions>
          <Button icon="check" mode=""
            onPress={() => agendar('Frango com acompanhamento', 35, '../assets/frango com salada.jpg')}>
            
          </Button>
        </Card.Actions>
      </Card>

      <Card style={styles.card}>
        <Card.Title title="Peixe Tatuapé" subtitle="Serve 2 pessoas. " />
        <Card.Content>
          <Image source={require('../assets/peixesTatuapé.jpg')} style={styles.image} />
          <Title style={styles.title}>R$40,00</Title>
        </Card.Content>
        <Card.Actions>
          <Button icon="check" mode=""
            onPress={() => agendar('Peixe Tatuapé', 20, '../assets/peixesTatuapé.jpg')}>
          </Button>
        </Card.Actions>
      </Card>

      <Card style={styles.card}>
        <Card.Title title="Fondue de Queijo" subtitle="Acompanha: Carne, Frango, Batata, Torrada, Calabresa." />
        <Card.Content>
          <Image source={require('../assets/fondue de queijo .jpeg')} style={styles.image} />
          <Title style={styles.title}>R$80,00</Title>
        </Card.Content>
        <Card.Actions>
          <Button icon="check" mode=""
            onPress={() => agendar('Fondue de Queijo', 80, '../assets/fondue de queijo .jpeg')}>
           
          </Button>
          
        </Card.Actions>
      </Card>

      <Card style={styles.card}>
        <Card.Title title="Carne com acompanhamento" subtitle="Acompanha: Dois tipos de arroz, batata." />
        <Card.Content>
          <Image source={require('../assets/carne com acompanhamento.jpg')} style={styles.image} />
          <Title style={styles.title}>R$30,00</Title>
        </Card.Content>
        <Card.Actions>
          <Button icon="check" mode=""
            onPress={() => agendar('Carne com acompanhamento', 30, '../assets/carne com acompanhamento.jpg')}>
          </Button>
        </Card.Actions>
      </Card>
    </ScrollView>
  );
}

export default HomeScreen;


