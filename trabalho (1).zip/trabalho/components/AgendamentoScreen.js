import { Image, Dimensions } from 'react-native';
import { Card, Button, Title, TextInput } from 'react-native-paper';
import { DatePickerModal, TimePickerModal } from 'react-native-paper-dates';
import { styles, valorFormatado } from './Utils';
import { useContext, useState } from 'react';
import { DataContext } from '../Context';

const AgendamentoScreen = ( {navigation} ) => {



  let { nomeServico, setNomeServico, valorServico, setValorServico, 
        imagemServico, setImagemServico, servicos, setServicos, total, setTotal } = useContext(DataContext);


  const confirmarAgendamento = () => {
    if (confirmarAgendamento != ""){
      let servico = servicos;
      servico.push({nome: nomeServico, valor: valorServico});
      setServicos(servico);
      setTotal(Number(total) + Number(valorServico));
      setNomeServico(null);
      setValorServico(0);
      setImagemServico(null);
      navigation.navigate('Carrinho');
    
    } else {
      alert("");
    }
  }

  return (
    <Card style={styles.card}>
      <Card.Title title={nomeServico} />
      <Card.Content>
        <Image source={imagemServico} style={styles.image}/>
        <Title style={styles.title}>
          {valorFormatado(valorServico)}
        </Title>
        
        
  
      </Card.Content>
      <Card.Actions>
        
        <Button icon="" mode="" onPress={() => confirmarAgendamento()} style={styles.button}>
          ADICIONAR AO CARRINHO
        </Button>
        <Button icon="" mode="" onPress={() => navigation.navigate('ServicosScreen')} style={styles.button}>
          Cancelar
        </Button>
      </Card.Actions>
    </Card>
    
  );
};

export default AgendamentoScreen;
