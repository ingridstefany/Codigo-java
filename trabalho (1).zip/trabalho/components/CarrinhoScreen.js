import { FlatList } from 'react-native';
import { Card, Paragraph, Button, List } from 'react-native-paper';
import { styles, valorFormatado } from './Utils';
import { useContext } from 'react';
import { DataContext } from '../Context';

const CarrinhoScreen = ({ navigation }) => {
  let { servicos, setServicos, total, setTotal } = useContext(DataContext);

  const excluirServico = (index) => {
    let servico = servicos;
    setTotal(total - servico[index].valor);
    servico = servico.filter((item) => item !== servico[index]);
    setServicos(servico);
  };

  return (
    <Card style={styles.card}>
      <Card.Title title="Carrinho" />
      <Card.Content>
        {total != 0 ? (
          <Paragraph>
            Valor total:
            {valorFormatado(total)}
          </Paragraph>
        ) : (
          <></>
        )}
        {servicos.length ? (
          <FlatList
            data={servicos}
            renderItem={({ item, index }) => {
              return (
                <List.Accordion
                  title={item.nome}
                  left={(props) => <List.Icon icon="food" />}>
                  <List.Item title={'Valor:' + valorFormatado(item.valor)} />
                  <List.Item
                    right={(props) => (
                      <Button
                        icon="delete"
                        mode="contained"
                        onPress={() => excluirServico(index)}>
                        Excluir
                      </Button>

                      
                    )}
                    
                  />
                </List.Accordion>
              );
            }}
          />
        ) : (
          <Paragraph>Nenhum Carrinho!</Paragraph>
        )}
      </Card.Content>
    </Card>
  );
};

export default CarrinhoScreen;
